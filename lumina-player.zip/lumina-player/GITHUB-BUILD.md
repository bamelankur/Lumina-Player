# Build the Lumina APK with GitHub Actions (free, no installs)

1. Create a free account at https://github.com (if you don't have one).
2. Create a new repository (private is fine — you get 2,000 free build
   minutes/month; one build takes ~10 minutes).
3. On the repo page, click "uploading an existing file".
4. Drag in the ENTIRE unzipped contents of `lumina-player.zip`
   (including the `.github` folder — it must come along).
5. Click Commit changes.
6. Go to the **Actions** tab → click **Build APK** → **Run workflow**
   (or wait — it also starts automatically on the upload).
7. When it finishes (~10 min, green checkmark), click the run →
   download the **lumina-release-apk** artifact (it's a zip — unzip it).
8. Copy `app-release.apk` to your Android phone, tap it, allow
   "install unknown apps" when asked, and open Lumina.

Every time you push a code change, a fresh APK builds automatically.
