# Lumina — Personal Media Player

A clean-room Flutter media player: your own video/photo library with
favourites, continue-watching, account sync, self-hosted media-server
support, and a Plus-upgrade stub.

## Features

- **Library** — import video/photo files from the device, or scan a whole
  folder. Videos: mp4, mkv, avi, mov, webm, m4v, 3gp. Photos: jpg, png,
  webp, gif, bmp.
- **Playback** — full-screen video player with play/pause, ±10 s skip and a
  seek bar. Remembers where you stopped.
- **Continue watching** — home-screen rail of in-progress videos.
- **Favourites** — heart anything; it lands in the Favourites tab.
- **Account sync** — free sign-in syncs favourites + watch progress across
  devices (pluggable backend; ships with a local stub — wire in Firebase or
  your own API in `lib/services/sync_service.dart`).
- **Media server** — connect to your own server. It just needs to expose
  `GET /api/media` returning
  `{"items":[{"id","title","url","type","durationMs"}]}`.
- **Plus** — one-time-upgrade placeholder, ready for real in-app purchase
  wiring.

## Build it

1. Install Flutter (https://docs.flutter.dev/get-started/install).
2. In this folder, generate the platform projects once:
   `flutter create --org com.lumina --project-name lumina .`
3. `flutter pub get`
4. `flutter run` (or `flutter build apk --release` for an installable APK).

## Project layout

```
lib/
  main.dart                 entry point
  app.dart                  providers + bottom navigation
  models/media_item.dart    MediaItem (video/photo, local/server)
  services/
    library_service.dart    library state + persistence
    favorites_service.dart  favourite ids
    progress_service.dart   watch positions + continue-watching
    sync_service.dart       account + sync backend (pluggable)
    server_service.dart     self-hosted media server connection
  screens/
    home_screen.dart        continue-watching + recently added
    library_screen.dart     filterable library, import, folder scan
    favorites_screen.dart   favourites grid
    player_screen.dart      video player, saves progress
    photo_viewer_screen.dart pinch-to-zoom photo viewer
    settings_screen.dart    account, sync, server, Plus, about
  widgets/media_card.dart   grid tile with progress + favourite badge
```

## Notes

- Local data is stored on-device with SharedPreferences. The sync backend
  is a stub — point `SyncBackend` at your own cloud store for real
  cross-device sync.
- Deliberately no third-party "module"/plugin loader: every content source
  is either your own files or your own server.
