import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kProgressKey = 'lumina.progress.v1';

/// Remembers playback positions so users can continue watching.
/// An item counts as "in progress" when watched past 2% but under 95%.
class ProgressService extends ChangeNotifier {
  final Map<String, int> _positionsMs = {};
  final Map<String, int> _durationsMs = {};
  bool _loaded = false;

  bool get isLoaded => _loaded;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProgressKey);
    if (raw != null) {
      try {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        for (final entry in map.entries) {
          final v = entry.value as Map<String, dynamic>;
          _positionsMs[entry.key] = (v['positionMs'] as num).toInt();
          _durationsMs[entry.key] = (v['durationMs'] as num).toInt();
        }
      } catch (_) {
        // Corrupt cache: start fresh.
      }
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final map = {
      for (final id in _positionsMs.keys)
        id: {
          'positionMs': _positionsMs[id],
          'durationMs': _durationsMs[id] ?? 0,
        },
    };
    await prefs.setString(_kProgressKey, jsonEncode(map));
  }

  int positionMs(String id) => _positionsMs[id] ?? 0;

  double fraction(String id) {
    final duration = _durationsMs[id] ?? 0;
    if (duration <= 0) return 0;
    return (_positionsMs[id] ?? 0) / duration;
  }

  bool isInProgress(String id) {
    final f = fraction(id);
    return f > 0.02 && f < 0.95;
  }

  /// Ids worth showing in a "continue watching" rail, most recent first.
  List<String> get continueWatchingIds {
    final ids = _positionsMs.keys.where(isInProgress).toList();
    return ids.reversed.toList();
  }

  Future<void> savePosition({
    required String id,
    required int positionMs,
    required int durationMs,
  }) async {
    _positionsMs[id] = positionMs;
    _durationsMs[id] = durationMs;
    await _persist();
    notifyListeners();
  }

  Future<void> markFinished(String id) async {
    _positionsMs.remove(id);
    _durationsMs.remove(id);
    await _persist();
    notifyListeners();
  }

  /// Raw state for sync payloads.
  Map<String, Map<String, int>> get snapshot => {
        for (final id in _positionsMs.keys)
          id: {
            'positionMs': _positionsMs[id]!,
            'durationMs': _durationsMs[id] ?? 0,
          },
      };

  Future<void> replaceAll(Map<String, Map<String, int>> data) async {
    _positionsMs.clear();
    _durationsMs.clear();
    for (final entry in data.entries) {
      _positionsMs[entry.key] = entry.value['positionMs'] ?? 0;
      _durationsMs[entry.key] = entry.value['durationMs'] ?? 0;
    }
    await _persist();
    notifyListeners();
  }
}
