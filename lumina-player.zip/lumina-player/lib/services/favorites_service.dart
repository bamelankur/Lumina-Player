import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kFavoritesKey = 'lumina.favorites.v1';

/// Tracks the user's favourite items by id, persisted locally.
class FavoritesService extends ChangeNotifier {
  final Set<String> _ids = {};
  bool _loaded = false;

  bool get isLoaded => _loaded;
  bool isFavorite(String id) => _ids.contains(id);
  int get count => _ids.length;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    _ids.addAll(prefs.getStringList(_kFavoritesKey) ?? const []);
    _loaded = true;
    notifyListeners();
  }

  Future<void> toggle(String id) async {
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_kFavoritesKey, _ids.toList());
    notifyListeners();
  }

  /// Raw ids for sync payloads.
  List<String> get ids => _ids.toList();

  /// Applies ids received from sync, replacing local state.
  Future<void> replaceAll(List<String> ids) async {
    _ids
      ..clear()
      ..addAll(ids);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_kFavoritesKey, _ids.toList());
    notifyListeners();
  }
}
