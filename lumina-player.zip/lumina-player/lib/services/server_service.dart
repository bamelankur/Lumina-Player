import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/media_item.dart';

const _kServerKey = 'lumina.server.v1';

/// Connection details for one self-hosted media server.
class MediaServer {
  final String id;
  final String name;
  final String baseUrl;
  final String apiKey;

  const MediaServer({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.apiKey,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'baseUrl': baseUrl,
        'apiKey': apiKey,
      };

  factory MediaServer.fromJson(Map<String, dynamic> json) => MediaServer(
        id: json['id'] as String,
        name: json['name'] as String,
        baseUrl: json['baseUrl'] as String,
        apiKey: json['apiKey'] as String,
      );
}

/// Connects to the user's own media server and pulls its library.
/// Expected API: GET {baseUrl}/api/media with header X-Api-Key,
/// returning {"items":[{"id","title","url","type","durationMs"}]}.
class ServerService extends ChangeNotifier {
  MediaServer? _server;
  List<MediaItem> _serverItems = [];
  String? _lastError;
  bool _loaded = false;

  MediaServer? get server => _server;
  bool get connected => _server != null;
  List<MediaItem> get serverItems => List.unmodifiable(_serverItems);
  String? get lastError => _lastError;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kServerKey);
    if (raw != null) {
      try {
        _server = MediaServer.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        // Ignore a corrupt record.
      }
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    if (_server == null) {
      await prefs.remove(_kServerKey);
    } else {
      await prefs.setString(_kServerKey, jsonEncode(_server!.toJson()));
    }
  }

  /// Tests the connection and, on success, stores it and pulls the library.
  Future<bool> connect({
    required String name,
    required String baseUrl,
    required String apiKey,
  }) async {
    _lastError = null;
    final normalized =
        baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    final candidate = MediaServer(
      id: 'srv:${normalized.hashCode}',
      name: name.trim().isEmpty ? normalized : name.trim(),
      baseUrl: normalized,
      apiKey: apiKey,
    );
    try {
      final items = await _fetchLibrary(candidate);
      _server = candidate;
      _serverItems = items;
      await _persist();
      notifyListeners();
      return true;
    } catch (e) {
      _lastError = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<List<MediaItem>> _fetchLibrary(MediaServer server) async {
    final uri = Uri.parse('${server.baseUrl}/api/media');
    final res = await http.get(uri, headers: {'X-Api-Key': server.apiKey}).timeout(
          const Duration(seconds: 15),
        );
    if (res.statusCode != 200) {
      throw Exception('Server replied ${res.statusCode}');
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final items = (body['items'] as List? ?? const [])
        .map((e) => MediaItem.fromServerJson(e as Map<String, dynamic>, server.id))
        .toList();
    return items;
  }

  Future<bool> refresh() async {
    final server = _server;
    if (server == null) return false;
    try {
      _serverItems = await _fetchLibrary(server);
      _lastError = null;
      notifyListeners();
      return true;
    } catch (e) {
      _lastError = e.toString();
      notifyListeners();
      return false;
    }
  }

  /// Disconnects and returns the removed server id so the UI can purge
  /// merged items via [LibraryService.clearServerItems].
  Future<String?> disconnect() async {
    final id = _server?.id;
    _server = null;
    _serverItems = [];
    _lastError = null;
    await _persist();
    notifyListeners();
    return id;
  }
}
