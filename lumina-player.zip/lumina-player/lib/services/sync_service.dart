import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kAccountKey = 'lumina.account.v1';

/// A signed-in sync account. The free account is all sync needs.
class SyncAccount {
  final String email;
  final DateTime signedInAt;

  const SyncAccount({required this.email, required this.signedInAt});

  Map<String, dynamic> toJson() =>
      {'email': email, 'signedInAt': signedInAt.toIso8601String()};

  factory SyncAccount.fromJson(Map<String, dynamic> json) => SyncAccount(
        email: json['email'] as String,
        signedInAt: DateTime.parse(json['signedInAt'] as String),
      );
}

/// Pluggable sync backend. Swap [LocalSyncBackend] for a real cloud
/// implementation (e.g. Firebase) without touching the rest of the app.
abstract class SyncBackend {
  Future<void> push(String email, Map<String, dynamic> data);
  Future<Map<String, dynamic>?> pull(String email);
  String get name;
}

/// Keeps the last pushed payload in local storage. Useful for development
/// and as the offline fallback; replace with a cloud backend for real
/// cross-device sync.
class LocalSyncBackend implements SyncBackend {
  @override
  String get name => 'local';

  @override
  Future<void> push(String email, Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'lumina.sync.$email', jsonEncode({'data': data, 'at': DateTime.now().toIso8601String()}));
  }

  @override
  Future<Map<String, dynamic>?> pull(String email) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('lumina.sync.$email');
    if (raw == null) return null;
    try {
      final envelope = jsonDecode(raw) as Map<String, dynamic>;
      return envelope['data'] as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}

/// Coordinates account state and sync of favourites + watch progress.
/// The payload is last-write-wins keyed by item id.
class SyncService extends ChangeNotifier {
  SyncBackend _backend = LocalSyncBackend();
  SyncAccount? _account;
  DateTime? _lastSyncedAt;
  bool _loaded = false;

  SyncAccount? get account => _account;
  bool get signedIn => _account != null;
  DateTime? get lastSyncedAt => _lastSyncedAt;
  String get backendName => _backend.name;

  void useBackend(SyncBackend backend) {
    _backend = backend;
    notifyListeners();
  }

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kAccountKey);
    if (raw != null) {
      try {
        _account =
            SyncAccount.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        // Ignore a corrupt account record.
      }
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> signIn(String email) async {
    _account =
        SyncAccount(email: email.trim(), signedInAt: DateTime.now());
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAccountKey, jsonEncode(_account!.toJson()));
    notifyListeners();
  }

  Future<void> signOut() async {
    _account = null;
    _lastSyncedAt = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kAccountKey);
    notifyListeners();
  }

  /// Pushes favourites + progress to the backend.
  Future<void> pushNow({
    required List<String> favoriteIds,
    required Map<String, Map<String, int>> progress,
  }) async {
    final account = _account;
    if (account == null) return;
    await _backend.push(account.email, {
      'favorites': favoriteIds,
      'progress': progress,
      'device': 'this-device',
    });
    _lastSyncedAt = DateTime.now();
    notifyListeners();
  }

  /// Pulls remote state. Returns the payload for the caller to apply.
  Future<Map<String, dynamic>?> pullNow() async {
    final account = _account;
    if (account == null) return null;
    final data = await _backend.pull(account.email);
    _lastSyncedAt = DateTime.now();
    notifyListeners();
    return data;
  }
}
