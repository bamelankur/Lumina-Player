/// The kind of media an item holds.
enum MediaType { video, photo }

/// Where the item lives: on this device or on a connected media server.
enum MediaSource { local, server }

/// A single entry in the user's library.
class MediaItem {
  final String id;
  final String title;
  final String path;
  final MediaType type;
  final MediaSource source;
  final int? durationMs;
  final DateTime dateAdded;
  final String? serverId;

  const MediaItem({
    required this.id,
    required this.title,
    required this.path,
    required this.type,
    this.source = MediaSource.local,
    this.durationMs,
    required this.dateAdded,
    this.serverId,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'path': path,
        'type': type.name,
        'source': source.name,
        'durationMs': durationMs,
        'dateAdded': dateAdded.toIso8601String(),
        'serverId': serverId,
      };

  factory MediaItem.fromJson(Map<String, dynamic> json) => MediaItem(
        id: json['id'] as String,
        title: json['title'] as String,
        path: json['path'] as String,
        type: MediaType.values.byName(json['type'] as String),
        source: MediaSource.values.byName(json['source'] as String? ?? 'local'),
        durationMs: json['durationMs'] as int?,
        dateAdded: DateTime.parse(json['dateAdded'] as String),
        serverId: json['serverId'] as String?,
      );

  /// Builds an item from a self-hosted server's JSON record.
  /// Expected shape: {"id","title","url","type":"video"|"photo","durationMs"?}
  factory MediaItem.fromServerJson(
      Map<String, dynamic> json, String serverId) {
    final rawType = (json['type'] as String? ?? 'video').toLowerCase();
    return MediaItem(
      id: 'srv:$serverId:${json['id']}',
      title: json['title'] as String? ?? 'Untitled',
      path: json['url'] as String,
      type: rawType == 'photo' ? MediaType.photo : MediaType.video,
      source: MediaSource.server,
      durationMs: json['durationMs'] as int?,
      dateAdded: DateTime.now(),
      serverId: serverId,
    );
  }
}
