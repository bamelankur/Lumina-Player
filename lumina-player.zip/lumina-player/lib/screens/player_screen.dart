import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../models/media_item.dart';
import '../services/progress_service.dart';

/// Full-screen video player with basic controls. Saves watch progress
/// periodically and on exit so "continue watching" keeps working.
class PlayerScreen extends StatefulWidget {
  final MediaItem item;

  const PlayerScreen({super.key, required this.item});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  VideoPlayerController? _controller;
  bool _showControls = true;
  Timer? _hideTimer;
  Timer? _saveTimer;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final progressSvc = context.read<ProgressService>();
    try {
      final controller = widget.item.source == MediaSource.local
          ? VideoPlayerController.file(File(widget.item.path))
          : VideoPlayerController.networkUrl(Uri.parse(widget.item.path));
      _controller = controller;
      await controller.initialize();
      final resumeAt = progressSvc.positionMs(widget.item.id);
      if (resumeAt > 5000) {
        await controller.seekTo(Duration(milliseconds: resumeAt));
      }
      await controller.play();
      if (mounted) setState(() {});
      _saveTimer =
          Timer.periodic(const Duration(seconds: 10), (_) => _saveProgress());
      _armHideTimer();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  void _armHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && (_controller?.value.isPlaying ?? false)) {
        setState(() => _showControls = false);
      }
    });
  }

  Future<void> _saveProgress() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final position = controller.value.position.inMilliseconds;
    final duration = controller.value.duration.inMilliseconds;
    if (duration <= 0) return;
    if (position >= duration * 0.95) {
      await context.read<ProgressService>().markFinished(widget.item.id);
    } else {
      await context.read<ProgressService>().savePosition(
            id: widget.item.id,
            positionMs: position,
            durationMs: duration,
          );
    }
  }

  @override
  void dispose() {
    _saveProgress();
    _hideTimer?.cancel();
    _saveTimer?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () {
          setState(() => _showControls = !_showControls);
          if (_showControls) _armHideTimer();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_error != null)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(
                    'Could not play this video.\n$_error',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70),
                  ),
                ),
              )
            else if (controller == null || !controller.value.isInitialized)
              const Center(child: CircularProgressIndicator())
            else
              Center(
                child: AspectRatio(
                  aspectRatio: controller.value.aspectRatio,
                  child: VideoPlayer(controller),
                ),
              ),
            if (_showControls && controller != null && _error == null)
              _ControlsOverlay(
                controller: controller,
                title: widget.item.title,
                format: _fmt,
                onSeek: (_) => _armHideTimer(),
              ),
          ],
        ),
      ),
    );
  }
}

class _ControlsOverlay extends StatelessWidget {
  final VideoPlayerController controller;
  final String title;
  final String Function(Duration) format;
  final ValueChanged<double> onSeek;

  const _ControlsOverlay({
    required this.controller,
    required this.title,
    required this.format,
    required this.onSeek,
  });

  @override
  Widget build(BuildContext context) {
    final value = controller.value;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black54, Colors.transparent, Colors.black54],
          stops: [0.0, 0.35, 1.0],
        ),
      ),
      child: Column(
        children: [
          AppBar(
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.white,
            title: Text(title,
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(format(value.position),
                    style: const TextStyle(color: Colors.white)),
                Expanded(
                  child: Slider(
                    value: value.position.inMilliseconds.toDouble().clamp(
                        0,
                        value.duration.inMilliseconds.toDouble() > 0
                            ? value.duration.inMilliseconds.toDouble()
                            : 1),
                    max: value.duration.inMilliseconds.toDouble() > 0
                        ? value.duration.inMilliseconds.toDouble()
                        : 1,
                    onChanged: (v) {
                      controller.seekTo(
                          Duration(milliseconds: v.toInt()));
                      onSeek(v);
                    },
                  ),
                ),
                Text(format(value.duration),
                    style: const TextStyle(color: Colors.white)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  iconSize: 36,
                  color: Colors.white,
                  icon: const Icon(Icons.replay_10),
                  onPressed: () {
                    final target =
                        value.position - const Duration(seconds: 10);
                    controller.seekTo(target.isNegative
                        ? Duration.zero
                        : target);
                  },
                ),
                const SizedBox(width: 16),
                IconButton(
                  iconSize: 56,
                  color: Colors.white,
                  icon: Icon(value.isPlaying
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_filled),
                  onPressed: () => value.isPlaying
                      ? controller.pause()
                      : controller.play(),
                ),
                const SizedBox(width: 16),
                IconButton(
                  iconSize: 36,
                  color: Colors.white,
                  icon: const Icon(Icons.forward_10),
                  onPressed: () => controller.seekTo(
                    value.position + const Duration(seconds: 10),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
