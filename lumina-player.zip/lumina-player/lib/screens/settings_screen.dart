import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/favorites_service.dart';
import '../services/library_service.dart';
import '../services/progress_service.dart';
import '../services/server_service.dart';
import '../services/sync_service.dart';

/// Account, sync, media-server connection and Plus upgrade.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _emailCtrl = TextEditingController();
  final _serverNameCtrl = TextEditingController();
  final _serverUrlCtrl = TextEditingController();
  final _serverKeyCtrl = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _serverNameCtrl.dispose();
    _serverUrlCtrl.dispose();
    _serverKeyCtrl.dispose();
    super.dispose();
  }

  Future<void> _signIn() async {
    final email = _emailCtrl.text.trim();
    if (!email.contains('@')) {
      _snack('Enter a valid email address.');
      return;
    }
    await context.read<SyncService>().signIn(email);
    _snack('Signed in as $email.');
  }

  Future<void> _syncNow() async {
    final sync = context.read<SyncService>();
    final favorites = context.read<FavoritesService>();
    final progressSvc = context.read<ProgressService>();
    setState(() => _busy = true);
    try {
      await sync.pushNow(
        favoriteIds: favorites.ids,
        progress: progressSvc.snapshot,
      );
      final remote = await sync.pullNow();
      if (remote != null) {
        final favs = (remote['favorites'] as List? ?? const [])
            .map((e) => e.toString())
            .toList();
        await favorites.replaceAll(favs);
        final prog = (remote['progress'] as Map? ?? const {})
            .map((k, v) {
          final entry = v as Map;
          return MapEntry(k.toString(), {
            'positionMs': (entry['positionMs'] as num?)?.toInt() ?? 0,
            'durationMs': (entry['durationMs'] as num?)?.toInt() ?? 0,
          });
        });
        await progressSvc.replaceAll(prog);
      }
      if (mounted) _snack('Synced just now.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _connectServer() async {
    final servers = context.read<ServerService>();
    final library = context.read<LibraryService>();
    setState(() => _busy = true);
    try {
      final ok = await servers.connect(
        name: _serverNameCtrl.text,
        baseUrl: _serverUrlCtrl.text.trim(),
        apiKey: _serverKeyCtrl.text.trim(),
      );
      if (!mounted) return;
      if (ok) {
        final items = servers.serverItems;
        await library.mergeServerItems(items, servers.server!.id);
        _snack('Connected. Pulled ${items.length} items.');
      } else {
        _snack(servers.lastError ?? 'Connection failed.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _disconnectServer() async {
    final servers = context.read<ServerService>();
    final library = context.read<LibraryService>();
    final serverId = await servers.disconnect();
    if (serverId != null && mounted) {
      await library.clearServerItems(serverId);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final sync = context.watch<SyncService>();
    final server = context.watch<ServerService>();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Account', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (sync.signedIn) ...[
          ListTile(
            leading: const Icon(Icons.account_circle_outlined),
            title: Text(sync.account!.email),
            subtitle: Text(sync.lastSyncedAt == null
                ? 'Never synced'
                : 'Last synced ${sync.lastSyncedAt}'),
            trailing: TextButton(
              onPressed: () => context.read<SyncService>().signOut(),
              child: const Text('Sign out'),
            ),
          ),
          FilledButton.icon(
            onPressed: _busy ? null : _syncNow,
            icon: const Icon(Icons.sync),
            label: const Text('Sync now'),
          ),
        ] else ...[
          TextField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email',
              hintText: 'you@example.com',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: _busy ? null : _signIn,
            child: const Text('Sign in (free)'),
          ),
          const SizedBox(height: 4),
          Text(
            'Signing in enables cross-device sync of favourites and watch progress.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
        const Divider(height: 32),
        Text('Media server', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (server.connected) ...[
          ListTile(
            leading: const Icon(Icons.dns_outlined),
            title: Text(server.server!.name),
            subtitle: Text(server.server!.baseUrl),
            trailing: TextButton(
              onPressed: _busy ? null : _disconnectServer,
              child: const Text('Disconnect'),
            ),
          ),
          OutlinedButton.icon(
            onPressed: _busy
                ? null
                : () async {
                    final ok =
                        await context.read<ServerService>().refresh();
                    if (!mounted) return;
                    if (ok) {
                      await context
                          .read<LibraryService>()
                          .mergeServerItems(
                              context.read<ServerService>().serverItems,
                              context.read<ServerService>().server!.id);
                      _snack('Library refreshed.');
                    } else {
                      _snack(context.read<ServerService>().lastError ??
                          'Refresh failed.');
                    }
                  },
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh library'),
          ),
        ] else ...[
          TextField(
            controller: _serverNameCtrl,
            decoration: const InputDecoration(
              labelText: 'Server name',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _serverUrlCtrl,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              labelText: 'Base URL',
              hintText: 'https://media.example.com',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _serverKeyCtrl,
            decoration: const InputDecoration(
              labelText: 'API key',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: _busy ? null : _connectServer,
            child: const Text('Connect'),
          ),
          const SizedBox(height: 4),
          Text(
            'Connect to your own media server. It should expose GET /api/media returning {"items":[{"id","title","url","type","durationMs"}]}.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
        const Divider(height: 32),
        Text('Lumina Plus', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        const ListTile(
          leading: Icon(Icons.workspace_premium_outlined),
          title: Text('Lumina Plus'),
          subtitle: Text(
              'One-time upgrade: expanded backups, longer history, more devices, extra cloud space.'),
        ),
        OutlinedButton(
          onPressed: () => _snack('Plus purchase is not wired up yet.'),
          child: const Text('Upgrade (coming soon)'),
        ),
        const Divider(height: 32),
        Text('About', style: Theme.of(context).textTheme.titleMedium),
        const ListTile(
          title: Text('Lumina 1.0.0'),
          subtitle: Text('Your personal media library.'),
        ),
      ],
    );
  }
}
