import 'dart:io';

import 'package:flutter/material.dart';

import '../models/media_item.dart';

/// Pinch-to-zoom photo viewer.
class PhotoViewerScreen extends StatelessWidget {
  final MediaItem item;

  const PhotoViewerScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final Widget image = item.source == MediaSource.local
        ? Image.file(File(item.path), fit: BoxFit.contain)
        : Image.network(item.path, fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const Center(
                  child: Text('Could not load this photo',
                      style: TextStyle(color: Colors.white70)),
                ));

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: Text(item.title,
            maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 4.0,
          child: image,
        ),
      ),
    );
  }
}
