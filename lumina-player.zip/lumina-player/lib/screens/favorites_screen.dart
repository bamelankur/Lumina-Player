import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/media_item.dart';
import '../services/favorites_service.dart';
import '../services/library_service.dart';
import '../widgets/media_card.dart';
import 'photo_viewer_screen.dart';
import 'player_screen.dart';

/// Grid of the user's favourited items.
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  void _open(BuildContext context, MediaItem item) {
    if (item.type == MediaType.video) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PlayerScreen(item: item)),
      );
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PhotoViewerScreen(item: item)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final favIds = context.watch<FavoritesService>().ids.toSet();
    final items = context
        .watch<LibraryService>()
        .items
        .where((e) => favIds.contains(e.id))
        .toList();

    if (items.isEmpty) {
      return const Center(
        child: Text('Tap the heart on anything to keep it here.'),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 0.72,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final item = items[i];
        return MediaCard(item: item, onTap: () => _open(context, item));
      },
    );
  }
}
