import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/media_item.dart';
import '../services/library_service.dart';
import '../services/progress_service.dart';
import '../widgets/media_card.dart';
import 'photo_viewer_screen.dart';
import 'player_screen.dart';

/// Home: continue-watching rail plus recently added grid.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _open(BuildContext context, MediaItem item) {
    if (item.type == MediaType.video) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PlayerScreen(item: item)),
      );
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PhotoViewerScreen(item: item)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final library = context.watch<LibraryService>();
    final progress = context.watch<ProgressService>();

    final byId = {for (final e in library.items) e.id: e};
    final continueWatching = progress.continueWatchingIds
        .map((id) => byId[id])
        .whereType<MediaItem>()
        .toList();
    final recent = library.items.reversed.take(12).toList();

    if (!library.isLoaded) {
      return const Center(child: CircularProgressIndicator());
    }
    if (library.items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.video_library_outlined,
                  size: 72,
                  color: Theme.of(context).colorScheme.onSurfaceVariant),
              const SizedBox(height: 16),
              Text('Your library is empty',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                'Head to the Library tab to import videos and photos from your device.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        if (continueWatching.isNotEmpty) ...[
          Text('Continue watching',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          SizedBox(
            height: 190,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: continueWatching.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final item = continueWatching[i];
                return SizedBox(
                  width: 150,
                  child: MediaCard(
                      item: item, onTap: () => _open(context, item)),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
        ],
        Text('Recently added', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 0.72,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: recent.length,
          itemBuilder: (context, i) {
            final item = recent[i];
            return MediaCard(item: item, onTap: () => _open(context, item));
          },
        ),
      ],
    );
  }
}
