package com.lumina.player

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
